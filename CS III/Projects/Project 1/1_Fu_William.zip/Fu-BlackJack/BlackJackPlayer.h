/*********************
William Fu
Comp Sci 241
Project 1- BlackJack
Due: 1/26
Betsy Sanders
*********************/

#ifndef BLACKJACKPLAYER_H_INCLUDED
#define BLACKJACKPLAYER_H_INCLUDED

#include "Player.h"

class BlackjackPlayer: public Player
{

};


#endif // BLACKJACKPLAYER_H_INCLUDED
