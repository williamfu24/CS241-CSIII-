/****************
William Fu
Comp Sci 241
Project 4
Betsy Sanders
****************/
#ifndef DATATYPE_H_INCLUDED
#define DATATYPE_H_INCLUDED

#include	<string>
using namespace std;

typedef int dataType;


#endif // DATATYPE_H_INCLUDED
