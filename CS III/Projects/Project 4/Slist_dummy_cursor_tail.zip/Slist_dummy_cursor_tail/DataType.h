//	FILE: DataType.h
//	B Sanders, Rhodes College
//	CS 241, Fall 2012
//
//		Interface: define a common data type
//			for consistency across several files
//

#ifndef	DATATYPE_H
#define	DATATYPE_H

#include	<string>
using namespace std;

typedef string DataType;


#endif